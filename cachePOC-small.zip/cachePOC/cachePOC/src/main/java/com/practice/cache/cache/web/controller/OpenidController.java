package com.practice.cache.cache.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.practice.cache.cache.business.service.CacheService;
import com.practice.cache.cache.web.request.ScopeRequest;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1")
@Slf4j
public class OpenidController {

    @Autowired
    private CacheManager cacheManager;

    @Autowired
    private CacheService cacheService;


    @GetMapping("/openid/scope")
    public List<ScopeRequest> scopeRequestList(){
        if (cacheManager != null && cacheManager.getCache("scopesCache") != null) {
            Cache.ValueWrapper valueWrapper = Objects.requireNonNull(cacheManager.getCache("scopesCache")).get("scopesCache");
            return (valueWrapper != null) ? (List<ScopeRequest>) valueWrapper.get() : null;
        } else {
            return new ArrayList<>(); // Or manually call the cacheService.populateCacheScopes() here...
        }
    }


    @GetMapping("/test/openid/scope")
    public void populateCache() {
        cacheService.populateCacheScopes();
    }
}
