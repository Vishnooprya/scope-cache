package com.practice.cache.cache.business.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CacheService {

    private final RestTemplate restTemplate = new RestTemplate();

    @Autowired
    private CacheManager cacheManager;

   // @Scheduled(cron = "0 */1 * * * *")
    @Scheduled(fixedDelay = 30000)
    public void populateCacheScopes(){

        log.info("  [CACHE SCHEDULER] Running Cache Fetch at {}", LocalDateTime.now());
        ResponseEntity<ArrayList> forEntity = restTemplate.getForEntity("http://localhost:8081/api/v1/scopes", ArrayList.class);
        Cache scopeCacheFromManager = cacheManager.getCache("scopesCache");
        if (scopeCacheFromManager != null) {
              scopeCacheFromManager.put("scopesCache", forEntity.getBody());
        }
        log.info("  [CACHE SCHEDULER] cache: {}", Objects.requireNonNull(cacheManager.getCache("scopesCache")).getNativeCache());

    }
}
