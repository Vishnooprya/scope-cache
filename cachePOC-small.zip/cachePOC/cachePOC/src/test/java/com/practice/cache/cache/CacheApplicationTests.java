package com.practice.cache.cache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
