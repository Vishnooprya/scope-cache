package com.practice.scope.scopePOC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScopePocApplicationTests {

	@Test
	void contextLoads() {
	}

}
