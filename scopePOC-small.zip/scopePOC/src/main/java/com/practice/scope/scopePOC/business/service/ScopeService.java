package com.practice.scope.scopePOC.business.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.practice.scope.scopePOC.web.request.ScopeRequest;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ScopeService {

    private ArrayList<ScopeRequest> scopeList = new ArrayList<>();

    public ArrayList<ScopeRequest> getDummyScopes(){
        if (scopeList.size() == 0) {
            log.info("Fetching scopes for the first time");
            scopeList.add(ScopeRequest.builder().brand("RBS").scope("admin:write").build());
            scopeList.add(ScopeRequest.builder().brand("NWBI").scope("admin:write").build());
            scopeList.add(ScopeRequest.builder().brand("NWB").scope("admin:write").build());
            scopeList.add(ScopeRequest.builder().brand("RBSI").scope("admin:write").build());
            scopeList.add(ScopeRequest.builder().brand("UBN").scope("admin:write").build());
            scopeList.add(ScopeRequest.builder().brand("UBR").scope("admin:write").build());
            return scopeList;
        } else {
            log.info("Fetching scopes as it is");
            return scopeList;
        }
    }

    public void addDummyScopes(ScopeRequest request) {
        log.info("Adding new scope : {}", request);
        scopeList.add(request);
    }

}
