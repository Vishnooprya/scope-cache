package com.practice.scope.scopePOC.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.practice.scope.scopePOC.business.service.ScopeService;
import com.practice.scope.scopePOC.web.request.ScopeRequest;

@RestController
@RequestMapping("/api/v1")
public class ScopeController {
    @Autowired
    private ScopeService scopeService;

    @GetMapping("/scopes")
    public List<ScopeRequest> getAllScopes(){
        return scopeService.getDummyScopes();
    }

    @PostMapping("/scope")
    public String createScope(@RequestBody ScopeRequest request) {
        scopeService.addDummyScopes(request);
        return "Scopes Added";
    }

}
